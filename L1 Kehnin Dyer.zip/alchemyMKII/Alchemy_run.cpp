/******************************************************************************
*Author:		Kehnin Dyer
*File name:		Alchemy_run.cpp
*Date Created:	2012/04/12
*Modifed:		2012/04/12
******************************************************************************/

#include "Alchemy.h"
#include <iostream>


int main()
{
	Alchemy game;
	game.start();
	
	std::cin.ignore();
}

