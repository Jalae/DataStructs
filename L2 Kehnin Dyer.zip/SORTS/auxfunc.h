
#pragma once

template <typename T>
void swap(T & elem1, T & elem2)
{
	T tmp(elem2);
	elem2 = elem1;
	elem1 = tmp;
}